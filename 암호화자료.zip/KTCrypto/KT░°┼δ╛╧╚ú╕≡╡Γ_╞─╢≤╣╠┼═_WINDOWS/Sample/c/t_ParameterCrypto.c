
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ktfcryptapi.h"

void _LogBin(char* szTitle, unsigned char* pLog, int nSize);
int _Parameter_Crypto(int symmAlgo);

#define LOGSTR 	printf
#define LOGBIN	_LogBin

int main(int argc, char* argv[])
{
	int rv;

	// Initialize
	rv = CryptoLibInit();
	if ( rv <= 0 )
	{
		LOGSTR("CryptoLibInit fail : %d\n", rv);
		return -1;
	}

	// KTSSO_ALGO_SEED
	// KTSSO_ALGO_AES128
 	rv = _Parameter_Crypto(KTSSO_ALGO_SEED);

	// Finalize
	rv = CryptoLibFinal();
	return 0;
}


int _Parameter_Crypto(int symmAlgo)
{
	int rv;
	KEY_ID keyid = {0};
	PKEY	 pkey=NULL;
	unsigned char sesKey[32] = {0};
	unsigned char enc_seskey[256] = {0};
	unsigned char enc_msg[1024+16] = {0};
	unsigned char dec_msg[1024+16] = {0};
	unsigned char hashed[20] = {0};
	unsigned char hashexed[20] = {0};

	int len_enc_seskey, len_enc_msg, len_dec_msg, len_msg;

	const char* UserPhoneNum = "01099998888";
	const char* SiteInfo = "KTSite";
	const char* ResrgsNum = "1234567890123";
	const char* UserPassword = "userpasswor001";

	char	msg[256] = {0};	
	char	mdbuff[29] = {0};

	//////////////////////////////////////////////////////////////////////////
	// Encrypt
	// User Password Hash
	
	// KTSSO_ALGO_SHA1
	// KTSSO_ALGO_SHA256
	rv = Hash(hashed, 20, (unsigned char*)UserPassword, strlen(UserPassword), KTSSO_ALGO_SHA1);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::Hash fail : %d\n", rv);
		return rv;
	}

	rv = EncodeBase64(mdbuff, hashed, 20);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::Hash fail : %d\n", rv);
		return rv;
	}

	rv = HashEx(hashexed, 20, (unsigned char*)UserPassword, strlen(UserPassword), KTSSO_ALGO_SHA1);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::HashEx fail : %d\n", rv);
		return rv;
	}

	rv = EncodeBase64(mdbuff, hashexed, 20);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::HashEx fail : %d\n", rv);
		return rv;
	}

	len_msg = sprintf(msg, "KTFE_phonenum=%s&SSOE_siteinfo=%s&KTFE_resrgstnum=%s&KTFE_userhash=%s",
		UserPhoneNum, SiteInfo, ResrgsNum, mdbuff);
	LOGSTR("Plain Data : [%d] %s\n", len_msg, msg);

	// Get PublicKey
 	rv = STG_GetLastKeyID(keyid);
 	if ( rv <= 0 )
 	{
 		LOGSTR("=> [ERROR] SSOEncrypt::STG_GetLastKeyID fail : %d\n", rv);
 		return rv;
 	}
 
	rv = STG_GetPublicKey(keyid, &pkey);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::STG_GetPublicKey fail : %d\n", rv);
		return rv;
	}

	// SessionKey Encryption
	len_enc_seskey = sizeof(enc_seskey);
	rv = CreateSessionKey(sesKey, enc_seskey, &len_enc_seskey, pkey);
	ReleasePKey(pkey);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::CreateSessionKey fail : %d\n", rv);
		return rv;
	}

	LOGBIN("Encrypted SessionKey", enc_seskey, len_enc_seskey);

	// Message Encryption
	// Default SymmetricAlgo : SEED
	len_enc_msg = sizeof(enc_msg);	
	rv = EncryptData(enc_msg, &len_enc_msg, (unsigned char *)msg, len_msg, sesKey, symmAlgo);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::EncryptData fail : %d\n", rv);
		return rv;
	}

	LOGBIN("Encrypted MSG", enc_msg, len_enc_msg);

	memset(sesKey, 0, sizeof(sesKey));
	memset(msg, 0, sizeof(msg));
	//////////////////////////////////////////////////////////////////////////
	// Decrypt
	// Get PrivateKey
	rv = STG_GetPrivateKey(keyid, &pkey);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::STG_GetPrivateKey fail : %d\n", rv);
		return rv;
	}

	// SessionKey Decryption	
	rv = DecryptSessionKey(sesKey, enc_seskey, len_enc_seskey, pkey);
	ReleasePKey(pkey);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::DecryptSessionKey fail : %d\n", rv);
		return rv;
	}

	// Message Decryption
	len_dec_msg = sizeof(dec_msg);
	rv = DecryptData(dec_msg, &len_dec_msg, enc_msg, len_enc_msg, sesKey, symmAlgo);
	if ( rv <= 0 )
	{
		LOGSTR("=> [ERROR] SSOEncrypt::DecryptData fail : %d\n", rv);
		return rv;
	}
	
	LOGSTR("Decrypted MSG : [%d] %s\n", len_dec_msg, dec_msg);

	return 0;
}


//////////////////////////////////////////////////////////////////////////
void _LogBin(char* szTitle, unsigned char* pLog, int nSize)
{	
	static char buff[128] = {0};	
	int i, j, offset;
	
	LOGSTR("%s (%d Bytes)\r\n",szTitle, nSize);

	for( i=0; i<nSize; i+=16 )
	{	
		sprintf(buff, "0x%04X ", (int)(i/16));
		offset = 7;

		for ( j=0; j<16 && nSize>i+j; ++j)
		{
			sprintf( buff+offset, "%02X ", pLog[i+j] );
			offset += 3;
		}

		buff[offset++] = '\n';
		buff[offset++] = '\0';

		LOGSTR(buff);
	}
}
